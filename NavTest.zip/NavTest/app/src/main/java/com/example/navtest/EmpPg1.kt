package com.example.navtest

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.navtest.databinding.ActivityEmpPg1Binding
import com.google.android.material.bottomnavigation.BottomNavigationView

class EmpPg1 : AppCompatActivity() {

    private lateinit var binding: ActivityEmpPg1Binding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEmpPg1Binding.inflate(layoutInflater)
        setContentView(binding.root)

        val bottomNavigationView2 = findViewById<BottomNavigationView>(R.id.bottomNavViewEmp)
        bottomNavigationView2.selectedItemId = R.id.epg1

        bottomNavigationView2.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.epg1 -> return@setOnItemSelectedListener true
                R.id.epg2 -> {
                    startActivity(Intent(applicationContext, EmpPg2::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }
    }
}
