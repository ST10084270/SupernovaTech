package com.example.navtest

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import com.example.navtest.databinding.ActivityDonorPg1Binding
import com.example.navtest.databinding.ActivityDonorPg2Binding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth

class DonorPg2 : AppCompatActivity() {

    private var loginActivity: Button? = null
    private lateinit var binding: ActivityDonorPg2Binding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDonorPg2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavViewDonor)
        bottomNavigationView.selectedItemId = R.id.dpg2

        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.dpg2 -> return@setOnItemSelectedListener true
                R.id.dpg1 -> {
                    startActivity(Intent(applicationContext, DonorPg1::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }

        loginActivity = findViewById<View>(R.id.loginEmp) as Button
        loginActivity!!.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this@DonorPg2, LoginActivity::class.java))
        }

    }
}