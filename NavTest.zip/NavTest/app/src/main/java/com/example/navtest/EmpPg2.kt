package com.example.navtest

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import com.example.navtest.databinding.ActivityEmpPg2Binding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth

class EmpPg2 : AppCompatActivity() {

    private var logout: ImageButton? = null
    private lateinit var binding: ActivityEmpPg2Binding

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            binding = ActivityEmpPg2Binding.inflate(layoutInflater)
            setContentView(binding.root)

            val bottomNavigationView2 = findViewById<BottomNavigationView>(R.id.bottomNavViewEmp)
            bottomNavigationView2.selectedItemId = R.id.epg2

            bottomNavigationView2.setOnItemSelectedListener { item ->
                when (item.itemId) {
                    R.id.epg2 -> return@setOnItemSelectedListener true
                    R.id.epg1 -> {
                        startActivity(Intent(applicationContext, EmpPg1::class.java))
                        finish()
                        return@setOnItemSelectedListener true
                    }
                }
                false
            }

        logout = findViewById<View>(R.id.logout) as ImageButton
        logout!!.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this@EmpPg2, DonorPg1::class.java))
        }

    }

}