package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.theresaconnect.databinding.ActivityDetailRequestEmpBinding
import com.google.firebase.database.FirebaseDatabase

class DetailRequestEmp : AppCompatActivity() {

    private lateinit var binding: ActivityDetailRequestEmpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailRequestEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //retrieve bundle
        val bundle = intent.extras

        //extract appeal value
        val dataRequest = bundle?.getString("Appeal") ?: ""

        if (bundle != null) {
            binding.detRequestName.text = bundle.getString("Appeal")
            binding.detRequestUrgency.text = bundle.getString("Urgency")
            binding.detRequestAmount.text = bundle.getString("Quantity")
            binding.detRequestDesc.text = bundle.getString("Description")

        }

        //back btn on click listener
        binding.detReqBack.setOnClickListener {
            val intent = Intent(this@DetailRequestEmp, RequestEmp::class.java)
            startActivity(intent)
        }

        //delete btn on click listener
        binding.deleteRequestBtn.setOnClickListener {
            val reference2 = FirebaseDatabase.getInstance().getReference("St Theresa's Appeals")

            reference2.child(dataRequest).removeValue().addOnSuccessListener {
                Toast.makeText(this@DetailRequestEmp, "Deleted", Toast.LENGTH_SHORT).show()
                startActivity(Intent(applicationContext, RequestEmp::class.java))
                finish()
            }.addOnFailureListener {
                // handle failure
            }
        }

    }

}