package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.theresaconnect.databinding.ActivityUploadRequestEmpBinding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.util.ArrayList

class UploadRequestEmp : AppCompatActivity() {
    private lateinit var binding: ActivityUploadRequestEmpBinding
    private lateinit var databaseReference: DatabaseReference
    private lateinit var dataRequestList: ArrayList<DataClassRequestsEmp>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUploadRequestEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        databaseReference = FirebaseDatabase.getInstance().getReference("Appeals")
        dataRequestList = ArrayList()

        //back btn
        binding.upReqBack.setOnClickListener {
            val intent = Intent(this@UploadRequestEmp, RequestEmp::class.java)
            startActivity(intent)
        }

        //save btn
        binding.saveRequestButton.setOnClickListener {
            uploadData()
        }

    }

    //upload data to firebase
    private fun uploadData() {

        val builder = AlertDialog.Builder(this@UploadRequestEmp)
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()

        val request = binding.uploadRequest.text.toString()
        val urgency = binding.uploadRequestUrgency.text.toString()
        val amount = binding.uploadRequestAmount.text.toString()
        val desc = binding.uploadRequestDesc.text.toString()

        val dataClassRequestEmp = DataClassRequestsEmp(request, urgency, amount, desc)

        FirebaseDatabase.getInstance().getReference("St Theresa's Appeals").child(request)
            .setValue(dataClassRequestEmp).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this@UploadRequestEmp, "Saved", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }.addOnFailureListener { e ->
                Toast.makeText(
                    this@UploadRequestEmp, e.message.toString(), Toast.LENGTH_SHORT
                ).show()
            }

    }

}




