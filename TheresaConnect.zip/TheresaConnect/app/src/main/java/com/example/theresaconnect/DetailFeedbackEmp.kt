package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.theresaconnect.databinding.ActivityDetailFeedbackEmpBinding
import com.google.firebase.database.FirebaseDatabase

class DetailFeedbackEmp : AppCompatActivity() {

    private lateinit var binding: ActivityDetailFeedbackEmpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailFeedbackEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //retrieve bundle
        val bundle = intent.extras

        //extract name value
        val dataFeedbackName = bundle?.getString("Name") ?: ""

        if (bundle != null) {
            binding.detFeedName.text = bundle.getString("Name")
            binding.detFeedEmail.text = bundle.getString("Email")
            binding.detFeedType.text = bundle.getString("Query")
            binding.detFeedComment.text = bundle.getString("Comment")
        }

        //back btn on click
        binding.feedBack.setOnClickListener {
            val intent = Intent(this@DetailFeedbackEmp, FeedbackEmp::class.java)
            startActivity(intent)
        }


        //delete btn on click
        binding.deleteFeedbackBtn.setOnClickListener {
            val reference2 = FirebaseDatabase.getInstance().getReference("St Theresa's Feedback")

            reference2.child(dataFeedbackName).removeValue().addOnSuccessListener {
                Toast.makeText(this@DetailFeedbackEmp, "Deleted", Toast.LENGTH_SHORT).show()
                startActivity(Intent(applicationContext, FeedbackEmp::class.java))
                finish()
            }.addOnFailureListener {
                // handle failure
            }
        }

    }
}