package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.theresaconnect.databinding.ActivityUploadFeedbackDonorBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.util.ArrayList

class UploadFeedbackDonor : AppCompatActivity() {

    private lateinit var binding: ActivityUploadFeedbackDonorBinding
    private lateinit var databaseReference4: DatabaseReference
    private lateinit var dataFeedbackList: ArrayList<DataClassFeedbackEmp>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUploadFeedbackDonorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bottomNavDonor.background = null

        val bottomNavigationView1 = findViewById<BottomNavigationView>(R.id.bottom_nav_donor)
        bottomNavigationView1.selectedItemId = R.id.feedback1

        bottomNavigationView1.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.feedback1
                -> return@setOnItemSelectedListener true
                R.id.gallery1 -> {
                    startActivity(Intent(applicationContext, GalleryDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.requests1 -> {
                    startActivity(Intent(applicationContext, RequestDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.home1 -> {
                    startActivity(Intent(applicationContext, MainActivityDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.more1 -> {
                    startActivity(Intent(applicationContext, MoreInfoDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }

        databaseReference4 = FirebaseDatabase.getInstance().getReference("St Theresa's Feedback")
        dataFeedbackList = ArrayList()

        binding.submitFeedback.setOnClickListener {
            uploadData()
        }

    }

    //uploading data to firebase
    private fun uploadData() {

        val builder = AlertDialog.Builder(this@UploadFeedbackDonor)
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()

        val email = binding.uploadFeedbackEmail.text.toString()
        val name = binding.uploadFeedbackName.text.toString()
        val spec = binding.uploadFeedbackSpec.text.toString()
        val desc = binding.uploadFeedbackDesc.text.toString()



        val dataClassFeedbackEmp = DataClassFeedbackEmp(email, name, spec, desc)


        FirebaseDatabase.getInstance().getReference("St Theresa's Feedback").child(name)
            .setValue(dataClassFeedbackEmp).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this@UploadFeedbackDonor, "Saved", Toast.LENGTH_SHORT).show()

                    //clear the EditText fields after saving
                    binding.uploadFeedbackEmail.text.clear()
                    binding.uploadFeedbackName.text.clear()
                    binding.uploadFeedbackSpec.text.clear()
                    binding.uploadFeedbackDesc.text.clear()

                }
                dialog.dismiss()
            }.addOnFailureListener { e ->
                Toast.makeText(
                    this@UploadFeedbackDonor, e.message.toString(), Toast.LENGTH_SHORT
                ).show()
                dialog.dismiss()
            }
    }
}