package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import com.example.theresaconnect.databinding.ActivityDetailNoticeEmpBinding
import com.github.clans.fab.FloatingActionButton
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class DetailNoticeEmp : AppCompatActivity() {

    private lateinit var binding: ActivityDetailNoticeEmpBinding
    private lateinit var detailNotice: TextView
    private lateinit var detNoticeDate: TextView
    private lateinit var detNoticeDesc: TextView

    private lateinit var databaseReference: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailNoticeEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        databaseReference =
            FirebaseDatabase.getInstance().getReference("St Theresa's Notices & Events")

        detailNotice = binding.detailNotice
        detNoticeDate = binding.detNoticeDate
        detNoticeDesc = binding.detNoticeDesc

        //retrieve bundle
        val bundle = intent.extras

        //extract notice value
        val dataHeading = bundle?.getString("Notice") ?: ""

        if (bundle != null) {
            detailNotice.text = bundle.getString("Notice")
            detNoticeDate.text = bundle.getString("Date")
            detNoticeDesc.text = bundle.getString("Desc")
        }

        binding.detNoticeBack.setOnClickListener {
            val intent = Intent(this@DetailNoticeEmp, MainActivityEmp::class.java)
            startActivity(intent)
        }

        binding.deleteNoticeBtn.setOnClickListener {
            val reference2 = FirebaseDatabase.getInstance().getReference("St Theresa's Notices & Events")

            reference2.child(dataHeading).removeValue().addOnSuccessListener {
                Toast.makeText(this@DetailNoticeEmp, "Deleted", Toast.LENGTH_SHORT).show()
                startActivity(Intent(applicationContext, MainActivityEmp::class.java))
                finish()
            }.addOnFailureListener {
                // handle failure
            }
        }

    }



}
