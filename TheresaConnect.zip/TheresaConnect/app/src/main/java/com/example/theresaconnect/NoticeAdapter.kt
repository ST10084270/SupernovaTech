package com.example.theresaconnect

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView

class NoticeAdapter(private val context: Context, private var dataNoticeList: List<DataClassNoticeEmp>) : RecyclerView.Adapter<MyViewHolder1>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder1 {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.recycler_item_notice_emp, parent, false)
        return MyViewHolder1(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder1, position: Int) {
        holder.recNoticeTitle.text = dataNoticeList[position].dataHeading
        holder.recNoticeDate.text = dataNoticeList[position].dataDate
        holder.recNoticeDesc.text = dataNoticeList[position].dataDesc

        //vals that appear on rec card
        holder.recNoticeCard.setOnClickListener {
            val intent = Intent(context, DetailNoticeEmp::class.java)
            intent.putExtra("Notice", dataNoticeList[holder.adapterPosition].dataHeading)
            intent.putExtra("Date", dataNoticeList[holder.adapterPosition].dataDate)
            intent.putExtra("Desc", dataNoticeList[holder.adapterPosition].dataDesc)
            context.startActivity(intent)
        }

    }

    override fun getItemCount(): Int {
        return dataNoticeList.size
    }

}

class MyViewHolder1(itemView: View) : RecyclerView.ViewHolder(itemView) {
    var recNoticeTitle: TextView
    var recNoticeDate: TextView
    var recNoticeDesc: TextView
    var recNoticeCard: CardView

    init {
        recNoticeTitle = itemView.findViewById(R.id.recNoticeTitle)
        recNoticeDate = itemView.findViewById(R.id.recNoticeDate)
        recNoticeDesc = itemView.findViewById(R.id.recNoticeDesc)
        recNoticeCard = itemView.findViewById(R.id.recNoticeCard)
    }
}

