package com.example.theresaconnect

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.theresaconnect.databinding.FragmentNoticesBinding
import com.google.firebase.database.*

class NoticesFragment : Fragment() {

    private var _binding: FragmentNoticesBinding? = null
    private val binding get() = _binding!!

    private lateinit var dataNoticeList: ArrayList<DataClassNoticeEmp>
    private lateinit var adapter1: NoticeAdapter
    var databaseReference: DatabaseReference? = null
    var eventListener: ValueEventListener? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        //_binding = FragmentNoticesBinding.inflate(inflater, container, false)
        //return binding.root
        _binding = FragmentNoticesBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val gridLayoutManager = GridLayoutManager(requireContext(), 1)
        binding.notices.layoutManager = gridLayoutManager

        val builder = AlertDialog.Builder(requireContext())
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()

        dataNoticeList = ArrayList()
        adapter1 = NoticeAdapter(requireContext(), dataNoticeList)
        binding.notices.adapter = adapter1
        databaseReference = FirebaseDatabase.getInstance().getReference("St Theresa's Notices & Events")
        dialog.show()

        eventListener = databaseReference!!.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                dataNoticeList.clear()
                for (itemSnapshot in snapshot.children) {
                    val dataClassNoticeEmp = itemSnapshot.getValue(DataClassNoticeEmp::class.java)
                    if (dataClassNoticeEmp != null) {
                        dataNoticeList.add(dataClassNoticeEmp)
                    }
                }
                adapter1.notifyDataSetChanged()
                dialog.dismiss()
            }

            override fun onCancelled(error: DatabaseError) {
                dialog.dismiss()
            }
        })

     //setting to not be clickable
        binding.notices.addOnItemTouchListener(object : RecyclerView.SimpleOnItemTouchListener() {
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                return true
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
