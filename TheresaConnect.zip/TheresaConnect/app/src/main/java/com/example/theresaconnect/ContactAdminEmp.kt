package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.theresaconnect.databinding.ActivityContactAdminEmpBinding

class ContactAdminEmp : AppCompatActivity() {

    private lateinit var binding: ActivityContactAdminEmpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityContactAdminEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //back btn on click listener
        binding.devBack.setOnClickListener {
            val intent = Intent(this@ContactAdminEmp, MoreEmp::class.java)
            startActivity(intent)
        }
    }
}