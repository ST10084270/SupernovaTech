package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.theresaconnect.databinding.ActivityEmergencyNumbersEmpBinding

class EmergencyNumbersEmp : AppCompatActivity() {

    private lateinit var binding: ActivityEmergencyNumbersEmpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEmergencyNumbersEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //back btn on click listener
        binding.emergencyBack.setOnClickListener {
            val intent = Intent(this@EmergencyNumbersEmp, MoreEmp::class.java)
            startActivity(intent)
        }
    }
}