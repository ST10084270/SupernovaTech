package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.Manifest
import android.app.AlertDialog
import android.app.Dialog
import android.content.pm.PackageManager
import android.graphics.Rect
import android.location.GpsStatus
import android.location.Location
import android.view.MotionEvent
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.res.ResourcesCompat
import com.example.theresaconnect.databinding.ActivityFindUsDonorBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.api.IMapController
import org.osmdroid.bonuspack.routing.OSRMRoadManager
import org.osmdroid.bonuspack.routing.Road
import org.osmdroid.bonuspack.routing.RoadManager
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.FolderOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.IMyLocationConsumer
import org.osmdroid.views.overlay.mylocation.IMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay

class FindUsDonor : AppCompatActivity(), IMyLocationProvider, MapListener, GpsStatus.Listener {

    private lateinit var mMap: MapView
    private lateinit var controller: IMapController
    private lateinit var mMyLocationOverlay: MyLocationNewOverlay
    private val LOCATION_REQUEST_CODE = 100
    private var currentRouteIndex = 0

    //st theresa add
    val hotspotLocations = listOf(
        Pair("St Theresa's Child and Youth Care Center", GeoPoint(-29.83864, 30.97922))
    )

    private val hotspotMarker = mutableListOf<Marker>()

    private lateinit var binding: ActivityFindUsDonorBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFindUsDonorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.contactBack.setOnClickListener {
            val intent = Intent(this@FindUsDonor, MoreInfoDonor::class.java)
            startActivity(intent)
        }

        mMap = binding.map
        mMyLocationOverlay = MyLocationNewOverlay(GpsMyLocationProvider(this), mMap)

        Configuration.getInstance().load(
            applicationContext,
            getSharedPreferences(getString(R.string.app_name), MODE_PRIVATE)
        )

        mMap.setTileSource(TileSourceFactory.MAPNIK)
        mMap.mapCenter
        mMap.setMultiTouchControls(true)
        mMap.getLocalVisibleRect(Rect())

        mMyLocationOverlay = MyLocationNewOverlay(GpsMyLocationProvider(this), mMap)
        controller = mMap.controller

        mMyLocationOverlay.enableMyLocation()
        mMyLocationOverlay.enableFollowLocation()
        mMyLocationOverlay.isDrawAccuracyEnabled = true

        controller.setZoom(6.0)
        mMap.overlays.add(mMyLocationOverlay)
        setUpMap()
        mMap.addMapListener(this)

        managePermissions()

        val routeButton = findViewById<Button>(R.id.routeBtn)
        routeButton.setOnClickListener {
            addHotspotMarkers()
            calculateAndDisplayRoutes()
        }

        val animatedMarkerOverlay = object : Overlay(this) {
            override fun onSingleTapConfirmed(event: MotionEvent, mapView: MapView): Boolean {
                val geoPoint = mMyLocationOverlay.myLocation
                if (geoPoint != null) {
                    val latitude = geoPoint.latitude
                    val longitude = geoPoint.longitude

                    val dialog = Dialog(this@FindUsDonor)
                    dialog.setContentView(R.layout.custom)

                    val latitudeTextView = dialog.findViewById<TextView>(R.id.latitudeTextView)
                    val longitudeTextView = dialog.findViewById<TextView>(R.id.longitudeTextView)

                    latitudeTextView.text = "Latitude: $latitude"
                    longitudeTextView.text = "Longitude: $longitude"

                    dialog.show()
                } else {
                    Toast.makeText(
                        this@FindUsDonor,
                        "Location information not available.",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                return true
            }
        }

        mMap.overlays.add(animatedMarkerOverlay)


    }

    //meth to calc and display
    private fun calculateAndDisplayRoutes() {
        val startPoint = mMyLocationOverlay.myLocation

        if (startPoint == null) {
            Toast.makeText(this, "Your current location is not available.", Toast.LENGTH_SHORT).show()
            return
        }

        if (currentRouteIndex < hotspotLocations.size) {
            val (hotspotName, endPoint) = hotspotLocations[currentRouteIndex]

            // Use Coroutines to make a network request in the background
            GlobalScope.launch(Dispatchers.IO) {
                val roadManager = OSRMRoadManager(this@FindUsDonor, "OBP_Tuto/1.0")
                val road = roadManager.getRoad(arrayListOf(startPoint, endPoint))

                withContext(Dispatchers.Main) {
                    // Update the UI on the main thread
                    if (road.mStatus == Road.STATUS_OK) {
                        // Remove only road-related overlays
                        mMap.overlays.removeAll { it !is MyLocationNewOverlay }

                        // Add road overlay
                        val roadOverlay = RoadManager.buildRoadOverlay(road)
                        mMap.overlays.add(roadOverlay)

                        // Add road markers
                        val roadMarkers = FolderOverlay()
                        mMap.overlays.add(roadMarkers)

                        for (i in 0 until road.mNodes.size) {
                            val node = road.mNodes[i]

                            val nodeMarker = Marker(mMap)
                            nodeMarker.position = node.mLocation
                            nodeMarker.icon = ResourcesCompat.getDrawable(resources, R.drawable.marker_node, null)
                            nodeMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)

                            nodeMarker.title = "Step $i"
                            nodeMarker.snippet = node.mInstructions
                            nodeMarker.subDescription = Road.getLengthDurationText(
                                this@FindUsDonor,
                                node.mLength,
                                node.mDuration
                            )

                            roadMarkers.add(nodeMarker)
                        }

                        // Add hotspot markers
                        addHotspotMarkers()

                        mMap.invalidate()

                        withContext(Dispatchers.Main) {
                            if (road != null && road.mStatus == Road.STATUS_OK) {
                                val routeDetails =
                                    "Hotspot: $hotspotName\n" +
                                            "Start location: Your current location:  $startPoint\n" +
                                            "End Location: $endPoint\n" +
                                            "Distance: ${road.mLength} meters\n" +
                                            "Time: ${road.mDuration} seconds"
                                showRouteDetailsDialog(routeDetails)
                            } else {
                                Toast.makeText(
                                    this@FindUsDonor,
                                    "Error when loading the road - status=${road.mStatus}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
                }
            }

            currentRouteIndex++
        } else {
            // All hotspots have been shown
            currentRouteIndex = 0
        }
    }

    //meth to set up map
    private fun setUpMap() {

        if (!isLocationPermissionGranted()) {

            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ),
                LOCATION_REQUEST_CODE
            )
            return
        }


        if (mMyLocationOverlay != null) {

            mMyLocationOverlay.enableMyLocation()


            mMyLocationOverlay.enableFollowLocation()


            mMyLocationOverlay.isDrawAccuracyEnabled = true


            val currentLocation = mMyLocationOverlay.myLocation

            if (currentLocation != null) {

                mMap.controller.setCenter(currentLocation)
                mMap.controller.setZoom(16.0) // Adjust the zoom level as needed

                val icLocationMarker = Marker(mMap)
                icLocationMarker.position = currentLocation


                icLocationMarker.setOnMarkerClickListener { marker, mapView ->
                    val latitude = marker.position.latitude
                    val longitude = marker.position.longitude

                    val dialog = Dialog(this@FindUsDonor)
                    dialog.setContentView(R.layout.custom)

                    val latitudeTextView = dialog.findViewById<TextView>(R.id.latitudeTextView)
                    val longitudeTextView = dialog.findViewById<TextView>(R.id.longitudeTextView)

                    latitudeTextView.text = "Latitude:  $latitude"
                    longitudeTextView.text = "Longitude: $longitude"

                    dialog.show()

                    true
                }


                mMap.overlays.add(icLocationMarker)
            } else {

                Toast.makeText(this, "Location not available", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //meth to show route details
    private fun showRouteDetailsDialog(routeDetails: String) {
        runOnUiThread {
            val alertDialog = AlertDialog.Builder(this@FindUsDonor)
            alertDialog.setTitle("Route Details")
            alertDialog.setMessage(routeDetails)
            alertDialog.setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            alertDialog.create().show()

            if (currentRouteIndex < hotspotLocations.size) {

                calculateAndDisplayRoutes()
            }
        }
    }

    fun encodeGeoPoint(location: GeoPoint): String {
        val encodedLatitude = location.latitude.toString().replace(".", "_")
        val encodedLongitude = location.longitude.toString().replace(".", "_")
        return "$encodedLatitude$encodedLongitude"
    }

    //meth to add hotspot marker
    private fun addHotspotMarkers() {
        // Clear existing markers
        mMap.overlays.removeAll(hotspotMarker)

        for ((name, location) in hotspotLocations) {
            val marker = Marker(mMap)
            marker.position = location
            marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            marker.title = name
            marker.icon = ResourcesCompat.getDrawable(resources, R.drawable.img, null)

            // Add the marker to the list and the map's overlays
            hotspotMarker.add(marker)
            mMap.overlays.add(marker)
        }
    }



    override fun onScroll(event: ScrollEvent?): Boolean {
        // Handle map scroll event here
        return true
    }

    override fun onZoom(event: ZoomEvent?): Boolean {
        // Handle map zoom event here
        return false
    }

    override fun onGpsStatusChanged(event: Int) {
        // Handle GPS status changes here
    }

    override fun startLocationProvider(myLocationConsumer: IMyLocationConsumer?): Boolean {
        // Start location provider here
        return true
    }

    override fun stopLocationProvider() {
        // Stop location provider here
    }

    override fun getLastKnownLocation(): Location {
        // Get last known location here
        return Location("Last_known_location")
    }

    override fun destroy() {
        // Destroy resources here
    }

    //meth for permissions
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_REQUEST_CODE) {
            if (grantResults.isNotEmpty()) {
                for (result in grantResults) {
                    if (result == PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "Permission granted", Toast.LENGTH_LONG).show()
                        setUpMap()
                    } else {
                        Toast.makeText(this, "Location permissions denied", Toast.LENGTH_LONG)
                            .show()
                    }
                }
            }
        }
    }

    private fun managePermissions() {
        val requestPermissions = mutableListOf<String>()

        // Location permissions
        if (!isLocationPermissionGranted()) {
            requestPermissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
            requestPermissions.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        }

    }

    private fun isLocationPermissionGranted(): Boolean {
        val fineLocation = ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarseLocation = ActivityCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fineLocation && coarseLocation
    }
}
