package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContextCompat.startActivity
import com.example.theresaconnect.databinding.ActivityBankDetailsDonorBinding

class BankDetailsDonor : AppCompatActivity() {

    private lateinit var binding: ActivityBankDetailsDonorBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBankDetailsDonorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //back btn on click listener
        binding.bankBack.setOnClickListener {
            val intent = Intent(this@BankDetailsDonor, RequestDonor::class.java)
            startActivity(intent)
        }
    }
}