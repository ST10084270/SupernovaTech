package com.example.theresaconnect

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.theresaconnect.databinding.ActivityDetailGalleryEmpBinding
import com.google.firebase.database.FirebaseDatabase

class DetailGalleryEmp : AppCompatActivity() {

    private lateinit var binding: ActivityDetailGalleryEmpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailGalleryEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //retrieve bundle
        val bundle = intent.extras

        //extract name value
        val dataEmpName = bundle?.getString("Name") ?: ""

        if (bundle != null) {
            binding.detEmpName.text = bundle.getString("Name")
            binding.detEmpRole.text = bundle.getString("Role")
            binding.detEmpEmail.text = bundle.getString("Email")
        }

        //back btn on click
        binding.detNoticeBack.setOnClickListener {
            val intent = Intent(this@DetailGalleryEmp, GalleryEmp::class.java)
            startActivity(intent)
        }

        //delete btn on click
        binding.deleteEmpBtn.setOnClickListener {
            val reference = FirebaseDatabase.getInstance().getReference("St Theresa's Board & Staff")

            reference.child(dataEmpName).removeValue().addOnSuccessListener {
                Toast.makeText(this@DetailGalleryEmp, "Deleted", Toast.LENGTH_SHORT).show()
                startActivity(Intent(applicationContext, GalleryEmp::class.java))
                finish()
            }.addOnFailureListener {
                // handle failure
            }
        }

    }
}
