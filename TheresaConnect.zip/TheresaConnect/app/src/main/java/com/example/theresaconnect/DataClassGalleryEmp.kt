package com.example.theresaconnect

class DataClassGalleryEmp {

        var dataEmpName: String? = null
        var dataEmpRole: String? = null
        var dataEmpEmail: String? = null

        constructor(empName: String?, empRole: String?, empEmail: String?)
        {
            this.dataEmpName = empName
            this.dataEmpRole = empRole
            this.dataEmpEmail = empEmail
        }

    constructor(){
    }
}