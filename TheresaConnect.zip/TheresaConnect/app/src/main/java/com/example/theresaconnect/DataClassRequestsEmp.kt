package com.example.theresaconnect

class DataClassRequestsEmp {

    var dataRequest: String? = null
    var dataUrgency: String? = null
    var dataAmount: String? = null
    var dataReqDesc: String? = null

    constructor(request: String?, urgency: String?, amount: String?, desc: String?)
    {
        this.dataRequest = request
        this.dataUrgency = urgency
        this.dataAmount = amount
        this.dataReqDesc = desc
    }

    constructor(){
    }

}