package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.viewpager2.widget.ViewPager2
import com.example.theresaconnect.databinding.ActivityMainDonorBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout
import me.relex.circleindicator.CircleIndicator3

class MainActivityDonor : AppCompatActivity() {

    private lateinit var binding: ActivityMainDonorBinding

    //private lateinit var tabLayout: TabLayout
    private lateinit var viewPager2: ViewPager2
    private lateinit var adapter : FragmentPageAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainDonorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bottomNavDonor.background = null

        val bottomNavigationView1 = findViewById<BottomNavigationView>(R.id.bottom_nav_donor)
        bottomNavigationView1.selectedItemId = R.id.home1

        bottomNavigationView1.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.home1 -> return@setOnItemSelectedListener true
                R.id.gallery1 -> {
                    startActivity(Intent(applicationContext, GalleryDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.requests1 -> {
                    startActivity(Intent(applicationContext, RequestDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.feedback1 -> {
                    startActivity(Intent(applicationContext, UploadFeedbackDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.more1 -> {
                    startActivity(Intent(applicationContext, MoreInfoDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }


        viewPager2 = findViewById(R.id.viewPager2)
        adapter = FragmentPageAdapter(supportFragmentManager, lifecycle)
        viewPager2.adapter = adapter

        val indicator = setViewPager(viewPager2)

    }

    //sliding thing
    private fun setViewPager(viewPager: ViewPager2): CircleIndicator3 {
        val indicator = findViewById<CircleIndicator3>(R.id.indicator)
        indicator.setViewPager(viewPager)

        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                indicator.animatePageSelected(position)
            }
        })

        return indicator
    }


}