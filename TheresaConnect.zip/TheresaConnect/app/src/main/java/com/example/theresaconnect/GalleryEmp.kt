package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.GridLayoutManager
import com.example.theresaconnect.databinding.ActivityGalleryEmpBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database

class GalleryEmp : AppCompatActivity() {

    private lateinit var binding: ActivityGalleryEmpBinding
    private lateinit var dataGalleryList: ArrayList<DataClassGalleryEmp>
    private lateinit var adapter2: GalleryAdapter
    var databaseReference2: DatabaseReference? = null
    var eventListener2: ValueEventListener? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGalleryEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bottomNavEmp.background = null

        val bottomNavigationView2 = findViewById<BottomNavigationView>(R.id.bottom_nav_emp)
        bottomNavigationView2.selectedItemId = R.id.gallery2

        bottomNavigationView2.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.gallery2 -> return@setOnItemSelectedListener true
                R.id.home2 -> {
                    startActivity(Intent(applicationContext, MainActivityEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.requests2 -> {
                    startActivity(Intent(applicationContext, RequestEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.feedback2 -> {
                    startActivity(Intent(applicationContext, FeedbackEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.more2 -> {
                    startActivity(Intent(applicationContext, MoreEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }


        val gridLayoutManager = GridLayoutManager(this@GalleryEmp, 1)
        binding.empGallery.layoutManager = gridLayoutManager

        //alert dialog
        val builder = AlertDialog.Builder(this@GalleryEmp)
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()

        //initialize rec view and adapter, and ref to db
        dataGalleryList = java.util.ArrayList()
        adapter2 = GalleryAdapter(this@GalleryEmp, dataGalleryList)
        binding.empGallery.adapter = adapter2
        databaseReference2 = FirebaseDatabase.getInstance().getReference("St Theresa's Board & Staff")
        dialog.show()

        //listener to fetch data from db
        eventListener2 = databaseReference2!!.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                dataGalleryList.clear()
                for (itemSnapshot in snapshot.children) {
                    val dataClassGalleryEmp = itemSnapshot.getValue(DataClassGalleryEmp::class.java)
                    if (dataClassGalleryEmp != null) {
                        dataGalleryList.add(dataClassGalleryEmp)
                    }
                }
                adapter2.notifyDataSetChanged()
                dialog.dismiss()
            }

            override fun onCancelled(error: DatabaseError) {
                dialog.dismiss()
            }
        })

        binding.fabUploadEmp.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@GalleryEmp, UploadGalleryEmp::class.java)
            startActivity(intent)
        })


    }

}