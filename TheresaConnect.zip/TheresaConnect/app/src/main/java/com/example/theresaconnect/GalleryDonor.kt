package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.ImageButton
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.theresaconnect.databinding.ActivityGalleryDonorBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.database.*

class GalleryDonor : AppCompatActivity() {

    private lateinit var binding: ActivityGalleryDonorBinding
    private lateinit var dataGalleryList: ArrayList<DataClassGalleryEmp>
    private lateinit var adapter2: GalleryAdapter
    var databaseReference2: DatabaseReference? = null
    var eventListener2: ValueEventListener? = null
    private lateinit var deleteEmp: ImageButton


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGalleryDonorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bottomNavDonor.background = null

        val bottomNavigationView1 = findViewById<BottomNavigationView>(R.id.bottom_nav_donor)
        bottomNavigationView1.selectedItemId = R.id.gallery1

        bottomNavigationView1.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.gallery1 -> return@setOnItemSelectedListener true
                R.id.home1 -> {
                    startActivity(Intent(applicationContext, MainActivityDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.requests1 -> {
                    startActivity(Intent(applicationContext, RequestDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.feedback1 -> {
                    startActivity(Intent(applicationContext, UploadFeedbackDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.more1 -> {
                    startActivity(Intent(applicationContext, MoreInfoDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }


        val gridLayoutManager = GridLayoutManager(this@GalleryDonor, 1)
        binding.empGallery.layoutManager = gridLayoutManager

        val builder = AlertDialog.Builder(this@GalleryDonor)
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()

        dataGalleryList = java.util.ArrayList()
        adapter2 = GalleryAdapter(this@GalleryDonor, dataGalleryList)
        binding.empGallery.adapter = adapter2
        databaseReference2 = FirebaseDatabase.getInstance().getReference("St Theresa's Board & Staff")
        dialog.show()

        eventListener2 = databaseReference2!!.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                dataGalleryList.clear()
                for (itemSnapshot in snapshot.children) {
                    val dataClassGalleryEmp = itemSnapshot.getValue(DataClassGalleryEmp::class.java)
                    if (dataClassGalleryEmp != null) {
                        dataGalleryList.add(dataClassGalleryEmp)
                    }
                }
                adapter2.notifyDataSetChanged()
                dialog.dismiss()
            }

            override fun onCancelled(error: DatabaseError) {
                dialog.dismiss()
            }
        })

        //setting val to not be clickable
        binding.empGallery.addOnItemTouchListener(object : RecyclerView.SimpleOnItemTouchListener() {
            override fun onInterceptTouchEvent(rv: RecyclerView, e: MotionEvent): Boolean {
                return true
            }
        })

    }

}