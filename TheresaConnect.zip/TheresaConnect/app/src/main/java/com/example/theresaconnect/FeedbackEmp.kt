package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.GridLayoutManager
import com.example.theresaconnect.databinding.ActivityFeedbackEmpBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.database.*

class FeedbackEmp : AppCompatActivity() {

    private lateinit var binding: ActivityFeedbackEmpBinding
    private lateinit var dataFeedbackList: ArrayList<DataClassFeedbackEmp>
    private lateinit var adapter4: FeedbackAdapter
    var databaseReference4: DatabaseReference? = null
    var eventListener4: ValueEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFeedbackEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bottomNavigationView2 = findViewById<BottomNavigationView>(R.id.bottom_nav_emp)
        bottomNavigationView2.selectedItemId = R.id.feedback2

        binding.bottomNavEmp.background = null

        bottomNavigationView2.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.feedback2 -> return@setOnItemSelectedListener true
                R.id.gallery2 -> {
                    startActivity(Intent(applicationContext, GalleryEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.requests2 -> {
                    startActivity(Intent(applicationContext, RequestEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.home2 -> {
                    startActivity(Intent(applicationContext, MainActivityEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.more2 -> {
                    startActivity(Intent(applicationContext, MoreEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }


        val gridLayoutManager = GridLayoutManager(this@FeedbackEmp, 1)
        binding.recyclerViewFeedback.layoutManager = gridLayoutManager

        //alert dialog
        val builder = AlertDialog.Builder(this@FeedbackEmp)
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()

        //initialize rec view and adapter, and ref to db
        dataFeedbackList = java.util.ArrayList()
        adapter4 = FeedbackAdapter(this@FeedbackEmp, dataFeedbackList)
        binding.recyclerViewFeedback.adapter = adapter4
        databaseReference4 = FirebaseDatabase.getInstance().getReference("St Theresa's Feedback")
        dialog.show()

        //listener to fetch data from db
        eventListener4 = databaseReference4!!.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                dataFeedbackList.clear()
                for (itemSnapshot in snapshot.children) {
                    val dataClassFeedbackEmp = itemSnapshot.getValue(DataClassFeedbackEmp::class.java)
                    if (dataClassFeedbackEmp != null) {
                        dataFeedbackList.add(dataClassFeedbackEmp)
                    }
                }
                adapter4.notifyDataSetChanged()
                dialog.dismiss()
            }

            override fun onCancelled(error: DatabaseError) {
                dialog.dismiss()
            }
        })

        //listener for search bar
        binding.searchFeedback.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String): Boolean {
                searchList(newText)
                return true
            }
        })
    }

    //meth for searching feedback
    fun searchList(text: String) {
        val searchList = java.util.ArrayList<DataClassFeedbackEmp>()
        for (dataClass in dataFeedbackList) {
            if (dataClass.dataFeedbackName?.lowercase()?.contains(text.lowercase()) == true
            ) {
                searchList.add(dataClass)
            }
        }
        adapter4.searchDataList(searchList)
    }

}
