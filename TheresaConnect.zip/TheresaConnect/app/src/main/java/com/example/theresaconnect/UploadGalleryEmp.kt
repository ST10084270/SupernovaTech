package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.example.theresaconnect.databinding.ActivityUploadGalleryEmpBinding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import java.util.*

class UploadGalleryEmp : AppCompatActivity() {

        private lateinit var binding: ActivityUploadGalleryEmpBinding
        private lateinit var databaseReference: DatabaseReference
        private lateinit var dataGalleryList: ArrayList<DataClassGalleryEmp>

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            binding = ActivityUploadGalleryEmpBinding.inflate(layoutInflater)
            setContentView(binding.root)

            databaseReference = FirebaseDatabase.getInstance().getReference("Employee Gallery")
            dataGalleryList = ArrayList()

            //back btn
            binding.upGalBack.setOnClickListener {
                val intent = Intent(this@UploadGalleryEmp, GalleryEmp::class.java)
                startActivity(intent)
            }

            //save btn
            binding.saveGalleryButton.setOnClickListener {
                uploadData()
            }

        }//on create ends

        //uploading to firebase
        private fun uploadData() {

            val builder = AlertDialog.Builder(this@UploadGalleryEmp)
            builder.setCancelable(false)
            builder.setView(R.layout.progress_layout)
            val dialog = builder.create()
            dialog.show()

            val empName = binding.uploadEmpName.text.toString()
            val empRole = binding.uploadEmpRole.text.toString()
            val empEmail = binding.uploadEmpEmail.text.toString()

            val dataClassGalleryEmp = DataClassGalleryEmp(empName, empRole, empEmail)

            FirebaseDatabase.getInstance().getReference("St Theresa's Board & Staff").child(empName)
                .setValue(dataClassGalleryEmp).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this@UploadGalleryEmp, "Saved", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }.addOnFailureListener { e ->
                    Toast.makeText(
                        this@UploadGalleryEmp, e.message.toString(), Toast.LENGTH_SHORT
                    ).show()
                }

        }

    }




