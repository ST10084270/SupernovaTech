package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.GridLayoutManager
import com.example.theresaconnect.databinding.ActivityMainEmpBinding
import com.github.clans.fab.FloatingActionMenu
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.database.*


class MainActivityEmp : AppCompatActivity() {

    private lateinit var binding: ActivityMainEmpBinding
    private lateinit var dataNoticeList: ArrayList<DataClassNoticeEmp>
    private lateinit var adapter1: NoticeAdapter
    var databaseReference:DatabaseReference? = null
    var eventListener:ValueEventListener? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bottomNavEmp.background = null

        val bottomNavigationView2 = findViewById<BottomNavigationView>(R.id.bottom_nav_emp)
        bottomNavigationView2.selectedItemId = R.id.home2

        bottomNavigationView2.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.home2 -> return@setOnItemSelectedListener true
                R.id.gallery2 -> {
                    startActivity(Intent(applicationContext, GalleryEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.requests2 -> {
                    startActivity(Intent(applicationContext, RequestEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.feedback2 -> {
                    startActivity(Intent(applicationContext, FeedbackEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.more2 -> {
                    startActivity(Intent(applicationContext, MoreEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }

        val gridLayoutManager = GridLayoutManager(this@MainActivityEmp, 1)
        binding.notices.layoutManager = gridLayoutManager

        //alert dialog
        val builder = AlertDialog.Builder(this@MainActivityEmp)
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()

        //initialize rec view and adapter, and ref to db
        dataNoticeList = java.util.ArrayList()
        adapter1 = NoticeAdapter(this@MainActivityEmp, dataNoticeList)
        binding.notices.adapter = adapter1
        databaseReference = FirebaseDatabase.getInstance().getReference("St Theresa's Notices & Events")
        dialog.show()

        //listener to fetch data from db
        eventListener = databaseReference!!.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                dataNoticeList.clear()
                for (itemSnapshot in snapshot.children) {
                    val dataClassNoticeEmp = itemSnapshot.getValue(DataClassNoticeEmp::class.java)
                    if (dataClassNoticeEmp != null) {
                        dataNoticeList.add(dataClassNoticeEmp)
                    }
                }
                adapter1.notifyDataSetChanged()
                dialog.dismiss()
            }

            override fun onCancelled(error: DatabaseError) {
                dialog.dismiss()
            }
        })

        //on click listener for uploading event
        binding.fabUploadEvent.setOnClickListener {
            val intent = Intent(this, UploadNoticeEmp::class.java)
            startActivity(intent)
        }

    }

}