package com.example.theresaconnect

class DataClassFeedbackEmp {
    var dataFeedbackEmail: String? = null
    var dataFeedbackName: String? = null
    var dataFeedbackSpec: String? = null
    var dataFeedbackDesc: String? = null

    constructor(email: String?, name: String?, spec: String?, desc: String?) {
        this.dataFeedbackEmail = email
        this.dataFeedbackName = name
        this.dataFeedbackSpec = spec
        this.dataFeedbackDesc = desc
    }

    constructor() {
    }
}