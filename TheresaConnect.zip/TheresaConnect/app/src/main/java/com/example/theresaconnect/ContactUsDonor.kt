package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.theresaconnect.databinding.ActivityContactAdminEmpBinding
import com.example.theresaconnect.databinding.ActivityContactUsDonorBinding

class ContactUsDonor : AppCompatActivity() {

    private lateinit var binding: ActivityContactUsDonorBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityContactUsDonorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //back btn on click listener
        binding.contactBack.setOnClickListener {
            val intent = Intent(this@ContactUsDonor, MoreInfoDonor::class.java)
            startActivity(intent)
        }
    }
}