package com.example.theresaconnect

class DataClassNoticeEmp {

    var dataDate: String? = null
    var dataHeading: String? = null
    var dataDesc: String? = null


    constructor(dataDate: String?, dataHeading: String?, dataDesc: String?)
    {
        this.dataDate = dataDate
        this.dataHeading = dataHeading
        this.dataDesc = dataDesc
    }

    constructor(){
    }
}