package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import com.example.theresaconnect.databinding.ActivityMoreEmpBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth

class MoreEmp : AppCompatActivity() {

    private lateinit var binding: ActivityMoreEmpBinding
    private var contactAdmin: Button? = null
    private var emergencyNumbersEmp: Button? = null
    private var logout: ImageButton? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMoreEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bottomNavEmp.background = null

        val bottomNavigationView2 = findViewById<BottomNavigationView>(R.id.bottom_nav_emp)
        bottomNavigationView2.selectedItemId = R.id.more2

        bottomNavigationView2.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.more2 -> return@setOnItemSelectedListener true
                R.id.gallery2 -> {
                    startActivity(Intent(applicationContext, GalleryEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.requests2 -> {
                    startActivity(Intent(applicationContext, RequestEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.feedback2 -> {
                    startActivity(Intent(applicationContext, FeedbackEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.home2 -> {
                    startActivity(Intent(applicationContext, MainActivityEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }

        //on click listener for contacting admin btn
        contactAdmin = findViewById<View>(R.id.contactAdmin) as Button
        contactAdmin!!.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this@MoreEmp, ContactAdminEmp::class.java))
        }

        //on click listener for emergency numbers btn
        emergencyNumbersEmp = findViewById<View>(R.id.emergencyNumbers) as Button
        emergencyNumbersEmp!!.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this@MoreEmp, EmergencyNumbersEmp::class.java))
        }

        //on click listener for logout btn
        logout = findViewById<View>(R.id.logout) as ImageButton
        logout!!.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this@MoreEmp, MainActivityDonor::class.java))
        }

    }
}