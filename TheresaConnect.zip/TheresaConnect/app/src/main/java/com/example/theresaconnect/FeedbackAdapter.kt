package com.example.theresaconnect

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView

class FeedbackAdapter (private val context: Context, private var dataFeedbackList: List<DataClassFeedbackEmp>) : RecyclerView.Adapter<MyViewHolder4>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder4 {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.recycler_item_feedback_emp, parent, false)
        return MyViewHolder4(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder4, position: Int) {
        holder.recFeedbackName.text = dataFeedbackList[position].dataFeedbackName
        holder.recFeedbackType.text = dataFeedbackList[position].dataFeedbackSpec

        //vals that appear on rec card
        holder.recFeedbackCard.setOnClickListener {
            val intent = Intent(context, DetailFeedbackEmp::class.java)
            intent.putExtra("Name", dataFeedbackList[holder.adapterPosition].dataFeedbackName)
            intent.putExtra("Email", dataFeedbackList[holder.adapterPosition].dataFeedbackEmail)
            intent.putExtra("Query", dataFeedbackList[holder.adapterPosition].dataFeedbackSpec)
            intent.putExtra("Comment", dataFeedbackList[holder.adapterPosition].dataFeedbackDesc)

            context.startActivity(intent)
        }

    }

    override fun getItemCount(): Int {
        return dataFeedbackList.size
    }

    fun searchDataList(searchList: List<DataClassFeedbackEmp>){
        dataFeedbackList = searchList
        notifyDataSetChanged()
    }

}


class MyViewHolder4(itemView: View) : RecyclerView.ViewHolder(itemView) {
    var recFeedbackName: TextView
    var recFeedbackType: TextView
    var recFeedbackCard: CardView

    init {
        recFeedbackName = itemView.findViewById(R.id.recFeedbackName)
        recFeedbackType = itemView.findViewById(R.id.recFeedbackType)
        recFeedbackCard = itemView.findViewById(R.id.recFeedbackCard)
    }
}

