package com.example.theresaconnect

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView

class RequestAdapter (private val context: Context, private var dataRequestList: List<DataClassRequestsEmp>) : RecyclerView.Adapter<MyViewHolder3>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder3 {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.recycler_item_request_emp, parent, false)
        return MyViewHolder3(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder3, position: Int) {
        holder.recRequestName.text = dataRequestList[position].dataRequest
        holder.recRequestUrgency.text = dataRequestList[position].dataUrgency
        holder.recRequestQuantity.text = dataRequestList[position].dataAmount
        holder.recRequestDesc.text = dataRequestList[position].dataReqDesc

        //items that appear on rec card
        holder.recRequestCard.setOnClickListener {
            val intent = Intent(context, DetailRequestEmp::class.java)
            intent.putExtra("Appeal", dataRequestList[holder.adapterPosition].dataRequest)
            intent.putExtra("Urgency", dataRequestList[holder.adapterPosition].dataUrgency)
            intent.putExtra("Quantity", dataRequestList[holder.adapterPosition].dataAmount)
            intent.putExtra("Description", dataRequestList[holder.adapterPosition].dataReqDesc)

            context.startActivity(intent)
        }

    }

    override fun getItemCount(): Int {
        return dataRequestList.size
    }

}


class MyViewHolder3(itemView: View) : RecyclerView.ViewHolder(itemView) {
    var recRequestName: TextView
    var recRequestUrgency: TextView
    var recRequestQuantity: TextView
    var recRequestDesc: TextView
    var recRequestCard: CardView

    init {
        recRequestName = itemView.findViewById(R.id.recRequestName)
        recRequestUrgency = itemView.findViewById(R.id.recRequestUrgency)
        recRequestQuantity = itemView.findViewById(R.id.recRequestQuantity)
        recRequestDesc = itemView.findViewById(R.id.recRequestDesc)
        recRequestCard = itemView.findViewById(R.id.recRequestCard)
    }
}

