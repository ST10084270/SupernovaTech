package com.example.theresaconnect

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase
import android.app.DatePickerDialog
import android.widget.DatePicker
import java.text.SimpleDateFormat
import java.util.*
import com.example.theresaconnect.databinding.ActivityUploadNoticeEmpBinding
import com.github.clans.fab.FloatingActionButton
import com.google.firebase.database.DatabaseReference

class UploadNoticeEmp : AppCompatActivity() {

    private lateinit var binding: ActivityUploadNoticeEmpBinding
    private lateinit var databaseReference: DatabaseReference
    private lateinit var dataNoticesList: ArrayList<DataClassNoticeEmp>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUploadNoticeEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //on click for notice date
        binding.uploadNoticeDate.setOnClickListener {
            showDatePicker(DatePickerDialog.OnDateSetListener { view: DatePicker?, year: Int, monthOfYear: Int, dayOfMonth: Int ->

                //handle selected date
                val selectedDate = Calendar.getInstance()
                selectedDate.set(year, monthOfYear, dayOfMonth)

                //update ui with selected date
                val formattedDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(selectedDate.time)
                binding.uploadNoticeDate.setText(formattedDate)
            })
        }

        databaseReference = FirebaseDatabase.getInstance().getReference("Notices & Events")
        dataNoticesList = ArrayList()

        //back btn
        binding.upNoticeBack.setOnClickListener {
            val intent = Intent(this@UploadNoticeEmp, MainActivityEmp::class.java)
            startActivity(intent)
        }

        //save btn
        binding.saveNoticeButton.setOnClickListener {
            uploadData()
        }

    }//on create ends

    private fun showDatePicker(dateSetListener: DatePickerDialog.OnDateSetListener) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(this, dateSetListener, year, month, day)
        datePickerDialog.show()
    }

    //upload data to firebase
    private fun uploadData() {

        val builder = AlertDialog.Builder(this@UploadNoticeEmp)
        builder.setCancelable(false)
        builder.setView(R.layout.progress_layout)
        val dialog = builder.create()
        dialog.show()

        val date = binding.uploadNoticeDate.text.toString()
        val name = binding.uploadNoticeName.text.toString()
        val desc = binding.uploadNoticeDesc.text.toString()

            val dataClassNoticeEmp = DataClassNoticeEmp(date, name, desc)

        FirebaseDatabase.getInstance().getReference("St Theresa's Notices & Events").child(name)
                .setValue(dataClassNoticeEmp).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this@UploadNoticeEmp, "Saved", Toast.LENGTH_SHORT).show()
                        finish()
                    }
                }.addOnFailureListener { e ->
                    Toast.makeText(
                        this@UploadNoticeEmp, e.message.toString(), Toast.LENGTH_SHORT
                    ).show()
                }

        }

    }




