package com.example.theresaconnect

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView

class GalleryAdapter (private val context: Context, private var dataGalleryList: List<DataClassGalleryEmp>) : RecyclerView.Adapter<MyViewHolder2>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder2 {
        val view: View = LayoutInflater.from(parent.context).inflate(R.layout.recycler_item_gallery_emp, parent, false)
        return MyViewHolder2(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder2, position: Int) {
        holder.recEmpName.text = dataGalleryList[position].dataEmpName
        holder.recEmpRole.text = dataGalleryList[position].dataEmpRole
        holder.recEmpEmail.text = dataGalleryList[position].dataEmpEmail

        //vals appear on rec card
        holder.recGalleryCard.setOnClickListener {
            val intent = Intent(context, DetailGalleryEmp::class.java)
            intent.putExtra("Name", dataGalleryList[holder.adapterPosition].dataEmpName)
            intent.putExtra("Role", dataGalleryList[holder.adapterPosition].dataEmpRole)
            intent.putExtra("Email", dataGalleryList[holder.adapterPosition].dataEmpEmail)
            context.startActivity(intent)
        }

    }

    override fun getItemCount(): Int {
        return dataGalleryList.size
    }

}

    class MyViewHolder2(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var recEmpName: TextView
        var recEmpRole: TextView
        var recEmpEmail: TextView
        var recGalleryCard: CardView

        init {
            recEmpName = itemView.findViewById(R.id.recEmpName)
            recEmpRole = itemView.findViewById(R.id.recEmpRole)
            recEmpEmail = itemView.findViewById(R.id.recEmpEmail)
            recGalleryCard = itemView.findViewById(R.id.recGalleryCard)
        }
    }

