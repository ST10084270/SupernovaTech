package com.example.theresaconnect

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import com.example.theresaconnect.databinding.ActivityMoreInfoDonorBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth

class MoreInfoDonor : AppCompatActivity() {

    private lateinit var binding: ActivityMoreInfoDonorBinding
    private var loginEmp: Button? = null
    private var contactUs: Button? = null
    private var findUS: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMoreInfoDonorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bottomNavDonor.background = null


        val bottomNavigationView1 = findViewById<BottomNavigationView>(R.id.bottom_nav_donor)
        bottomNavigationView1.selectedItemId = R.id.more1

        bottomNavigationView1.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.more1 -> return@setOnItemSelectedListener true
                R.id.gallery1 -> {
                    startActivity(Intent(applicationContext, GalleryDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.requests1 -> {
                    startActivity(Intent(applicationContext, RequestDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.feedback1 -> {
                    startActivity(Intent(applicationContext, UploadFeedbackDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.home1 -> {
                    startActivity(Intent(applicationContext, MainActivityDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }

        //on click listener for secret login btn
        loginEmp = findViewById<View>(R.id.secretButton) as Button
        loginEmp!!.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this@MoreInfoDonor, LoginEmp::class.java))
        }

        //on click listener for contact us btn
        contactUs = findViewById<View>(R.id.contactUs) as Button
        contactUs!!.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this@MoreInfoDonor, ContactUsDonor::class.java))
        }

        //on click listener for find us btn
        findUS = findViewById<View>(R.id.findUS) as Button
        findUS!!.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this@MoreInfoDonor, FindUsDonor::class.java))
        }

    }
}