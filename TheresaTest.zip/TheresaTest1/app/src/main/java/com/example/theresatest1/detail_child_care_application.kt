package com.example.theresatest1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class detail_child_care_application : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_child_care_application)
    }
}