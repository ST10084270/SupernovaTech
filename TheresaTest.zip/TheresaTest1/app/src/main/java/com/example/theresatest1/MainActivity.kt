package com.example.theresatest1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.theresatest1.databinding.ActivityMainEuBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainEuBinding
    private var fabAbout: FloatingActionButton? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainEuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavView)
        bottomNavigationView.selectedItemId = R.id.home

        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.home -> return@setOnItemSelectedListener true
                R.id.gallery -> {
                    startActivity(Intent(applicationContext, GalleryEU::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.requests -> {
                    startActivity(Intent(applicationContext, RequestActivityEU::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.feedback -> {
                    startActivity(Intent(applicationContext, FeedbackActivityEU::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.more -> {
                    startActivity(Intent(applicationContext, MoreActivityEU::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }

    }




}