package com.example.theresatest1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton

class ChildCareEU : AppCompatActivity() {

    private lateinit var ccaBack: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload_child_care_application)

        //back button - listener
        ccaBack = findViewById(R.id.ccaBack)

        ccaBack.setOnClickListener {
            val intent = Intent(this@ChildCareEU, MainActivity::class.java)
            startActivity(intent)
        }

    }
}