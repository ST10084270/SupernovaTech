package com.example.theresatest1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton

class AboutUsEU : AppCompatActivity() {

    private lateinit var aboutBack: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_us_eu)

        //back button - listener
        aboutBack = findViewById(R.id.aboutBack)

        aboutBack.setOnClickListener {
            val intent = Intent(this@AboutUsEU, MoreActivityEU::class.java)
            startActivity(intent)
        }

    }
}