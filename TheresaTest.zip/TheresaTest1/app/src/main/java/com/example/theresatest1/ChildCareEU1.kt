package com.example.theresatest1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ChildCareEU1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_child_care_info)
    }
}