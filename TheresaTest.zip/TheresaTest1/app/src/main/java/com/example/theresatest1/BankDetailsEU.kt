package com.example.theresatest1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton

class BankDetailsEU : AppCompatActivity() {

    private lateinit var bankBack: ImageButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bank_details_eu)

        //back button - listener
        bankBack = findViewById(R.id.bankBack)

        bankBack.setOnClickListener {
            val intent = Intent(this@BankDetailsEU, MoreActivityEU::class.java)
            startActivity(intent)
        }

    }
}