package com.example.theresatestemp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.theresatestemp.databinding.ActivityMainEmpBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivityEmp : AppCompatActivity() {

    private lateinit var binding: ActivityMainEmpBinding

    private var fabUploadEvent: FloatingActionButton? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bottomNavigationView2 = findViewById<BottomNavigationView>(R.id.bottom_nav_emp)
        bottomNavigationView2.selectedItemId = R.id.home2

        bottomNavigationView2.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.home2 -> return@setOnItemSelectedListener true
                R.id.gallery2 -> {
                    startActivity(Intent(applicationContext, GalleryEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.requests2 -> {
                    startActivity(Intent(applicationContext, RequestEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.feedback2 -> {
                    startActivity(Intent(applicationContext, FeedbackEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.more2 -> {
                    startActivity(Intent(applicationContext, MoreEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }

        fabUploadEvent = findViewById<View>(R.id.fabUploadEvent) as FloatingActionButton

        //on click listener for btn to upload events/notice pg
        fabUploadEvent!!.setOnClickListener { openUploadNoticeEmp() }

    }

    fun openUploadNoticeEmp() {
        val intent = Intent(this, openUploadNoticeEmp()::class.java)
        startActivity(intent)
    }

}