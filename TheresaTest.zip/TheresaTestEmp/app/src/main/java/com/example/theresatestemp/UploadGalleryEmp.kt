package com.example.theresatestemp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class UploadGalleryEmp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload_gallery_emp)
    }
}