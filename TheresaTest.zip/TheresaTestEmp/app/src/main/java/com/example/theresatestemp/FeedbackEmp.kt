package com.example.theresatestemp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.theresatestemp.databinding.ActivityFeedbackEmpBinding
import com.google.android.material.bottomnavigation.BottomNavigationView

class FeedbackEmp : AppCompatActivity() {

    private lateinit var binding: ActivityFeedbackEmpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFeedbackEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bottomNavigationView2 = findViewById<BottomNavigationView>(R.id.bottom_nav_emp)
        bottomNavigationView2.selectedItemId = R.id.feedback2

        bottomNavigationView2.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.feedback2 -> return@setOnItemSelectedListener true
                R.id.gallery2 -> {
                    startActivity(Intent(applicationContext, GalleryEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.requests2 -> {
                    startActivity(Intent(applicationContext, RequestEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.home2 -> {
                    startActivity(Intent(applicationContext, MainActivityEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.more2 -> {
                    startActivity(Intent(applicationContext, MoreEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }
    }
}
