package com.example.theresatestemp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class UploadRequestEmp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload_request_emp)
    }
}