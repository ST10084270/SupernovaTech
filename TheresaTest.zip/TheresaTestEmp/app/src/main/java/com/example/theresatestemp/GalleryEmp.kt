package com.example.theresatestemp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.theresatestemp.databinding.ActivityGalleryEmpBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class GalleryEmp : AppCompatActivity() {

    private lateinit var binding: ActivityGalleryEmpBinding

    private var fabUploadEmp: FloatingActionButton? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGalleryEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bottomNavigationView2 = findViewById<BottomNavigationView>(R.id.bottom_nav_emp)
        bottomNavigationView2.selectedItemId = R.id.gallery2

        bottomNavigationView2.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.gallery2 -> return@setOnItemSelectedListener true
                R.id.home2 -> {
                    startActivity(Intent(applicationContext, MainActivityEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.requests2 -> {
                    startActivity(Intent(applicationContext, RequestEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.feedback2 -> {
                    startActivity(Intent(applicationContext, FeedbackEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.more2 -> {
                    startActivity(Intent(applicationContext, MoreEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }

        fabUploadEmp = findViewById<View>(R.id.fabUploadEmp) as FloatingActionButton

        //on click listener for btn to upload events/notice pg
        fabUploadEmp!!.setOnClickListener { openUploadGalleryEmp() }

    }

    fun openUploadGalleryEmp() {
        val intent = Intent(this, openUploadGalleryEmp()::class.java)
        startActivity(intent)
    }
}