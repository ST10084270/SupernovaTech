package com.example.theresatestemp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import com.example.theresatestemp.databinding.ActivityMoreEmpBinding
import com.google.android.material.bottomnavigation.BottomNavigationView

class MoreEmp : AppCompatActivity() {

    private lateinit var binding: ActivityMoreEmpBinding

    private var logout: ImageButton? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMoreEmpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bottomNavigationView2 = findViewById<BottomNavigationView>(R.id.bottom_nav_emp)
        bottomNavigationView2.selectedItemId = R.id.more2

        bottomNavigationView2.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.more2 -> return@setOnItemSelectedListener true
                R.id.gallery2 -> {
                    startActivity(Intent(applicationContext, GalleryEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.requests2 -> {
                    startActivity(Intent(applicationContext, RequestEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.feedback2 -> {
                    startActivity(Intent(applicationContext, FeedbackEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.home2 -> {
                    startActivity(Intent(applicationContext, MainActivityEmp::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }

        //this code will work once it is connect to firebase
     /*   logout = findViewById<View>(R.id.logout) as ImageButton
        logout!!.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this@MoreEmp, MainActivityDonor::class.java))
        }*/

    }
}