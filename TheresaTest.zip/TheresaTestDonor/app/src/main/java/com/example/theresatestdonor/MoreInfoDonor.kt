package com.example.theresatestdonor

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.theresatestdonor.databinding.ActivityMoreInfoDonorBinding
import com.google.android.material.bottomnavigation.BottomNavigationView

class MoreInfoDonor : AppCompatActivity() {

    private lateinit var binding: ActivityMoreInfoDonorBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMoreInfoDonorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bottomNavigationView1 = findViewById<BottomNavigationView>(R.id.bottom_nav_donor)
        bottomNavigationView1.selectedItemId = R.id.more1

        bottomNavigationView1.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.more1 -> return@setOnItemSelectedListener true
                R.id.gallery1 -> {
                    startActivity(Intent(applicationContext, GalleryDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.requests1 -> {
                    startActivity(Intent(applicationContext, RequestDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.feedback1 -> {
                    startActivity(Intent(applicationContext, UploadFeedbackDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
                R.id.home1 -> {
                    startActivity(Intent(applicationContext, MainActivityDonor::class.java))
                    finish()
                    return@setOnItemSelectedListener true
                }
            }
            false
        }
    }
}