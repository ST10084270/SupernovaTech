package com.example.theresatestdonor

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class FindUsDonor : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_find_us_donor)
    }
}